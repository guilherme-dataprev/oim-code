import './App.css'
import Capa from '@/components/Capa';
import FolhaRosto from './components/FolhaRosto';
import Expediente from './components/Expediente';
import Agradecimentos from './components/Agradecimentos';
import ListaFiguras from './components/ListaFiguras';
import ListaSiglas from './components/ListaSiglas';
import IconesOrganizadores from './components/IconesOrganizadores';
import Sumario from './components/Sumario';
import Modulo1 from './components/Modulo1';
import Modulo2 from './components/Modulo2';
import Modulo3 from './components/Modulo3';
import Modulo4 from './components/Modulo4';
import Modulo5 from './components/Modulo5';
import Glossario from './components/Glossario';
import Contracapa from './components/Contracapa';

function App() {
  return (
    <div className='book'>
      <Capa />
      <FolhaRosto />
      <Expediente />
      <Agradecimentos />
      <ListaFiguras />
      <ListaSiglas />
      <IconesOrganizadores />
      <Sumario />
      <Modulo1 />
      <Modulo2 />
      <Modulo3 />
      <Modulo4 />
      <Modulo5 />
      <Glossario />
      <Contracapa />
    </div>
  )
}

export default App;
