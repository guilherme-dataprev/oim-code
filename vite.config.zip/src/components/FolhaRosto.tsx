function FolhaRosto() {
  return (
    <div className="folha-rosto">
      <div>
        <p>As opiniões expressas nesta publicação são dos autores e não refletem necessariamente a opinião da Organização Internacional para as Migrações (OIM). As denominações utilizadas no presente material e a maneira como são apresentados os dados não implicam, por parte da OIM, qualquer opinião sobre a condição jurídica dos países, territórios, cidades ou áreas, ou mesmo de suas autoridades, tampouco sobre a delimitação de suas fronteiras ou limites.</p>
        <p>A OIM está comprometida com o princípio de que a migração ordenada e humana beneficia os migrantes e a sociedade. Por seu caráter de organização intergovernamental, a OIM atua com seus parceiros governamentais, intergovernamentais e não governamentais para: ajudar a enfrentar os crescentes desafios da gestão da migração; fomentar a compreensão das questões migratórias; promover o desenvolvimento social e econômico por meio da migração; e garantir o respeito pela dignidade humana e bem-estar dos migrantes.</p>
        <p><strong>Esta publicação foi possível graças ao apoio do Escritório de População, Refugiados e Migração (PRM) do Departamento de Estado dos Estados Unidos da América. As opiniões expressas aqui são dos autores e não refletem necessariamente a opinião da OIM e dos parceiros.</strong></p>
      </div>
      <div>
        <p><strong>Publicado por:</strong></p>
        <p>SAUS Quadra 5 - Bloco N - Ed. OAB - 4º andar - Asa Sul CEP: 70070-913 - Brasília-DF - Brasil</p>
        <p>E-mail: iombrazil@iom.int</p>
        <p>Website: https://brazil.iom.int/pt-br</p>
      </div>
      <div>
        <p><strong>Expediente técnico da publicação</strong></p>
        <p>Revisão técnica: Jennifer Alvarez e Manuela de Castro Costa Netto</p>
        <p>Revisão de língua portuguesa: Manuela de Castro Costa Netto</p>
        <p>Projeto gráfico e diagramação: Guilherme Teles da Mota</p>
      </div>
      <div className="cip">
        <p>Dados Internacionais de Catalogação da Publicação (CIP)</p>
        <p className="tab">(Câmara Brasileira do Livro, SP Brasil)</p>
        <hr />
        <p className="tab">Matriz de monitoramento de deslocamento (DTM) nacional sobre a população indígena do fluxo migratório venezuelano no Brasil [livro eletrônico] : rodada 2023 / [autoras] Cinthia Barros, Jennifer Alvarez, Luciana Elena Vazquez. -- 2. ed. --Brasília, DF : OIM - Organização Internacional para as Migrações, 2023. PDF</p>
        <p>ISBN 978-65-87187-23-5</p>
        <p className="tab">1. Brasil - Migração 2. Migração - 2. Políticas públicas 3. Povos indígenas</p>
        <div className="two-col"><span>23-165319</span><span>CDD-304.881</span></div>
        <hr />
        <p className="tab">Índices para catálogo sistemático:</p>
        <p className="tab">1. Brasil : Migrantes venezuelanos : Sociologia: Antropologia 304.881</p>
        <p className="tab">Tábata Alves da Silva - Bibliotecária - CRB-8/9253</p>
      </div>

      <div>
        <p>Esta publicação não foi editada oficialmente pela OIM.</p>
        <p>Este relatório foi publicado sem aprovação da Unidade de Publicações da OIM (PUB) em relação à adesão aos padrões de estilo e marca da OIM.</p>
        <p>Este relatório foi publicado sem endosso da Unidade de Pesquisa da OIM (RES).</p>
      </div>
      <div>
        <p>Foto da capa:</p>
        <p>© OIM 2023/ Leonardo.ai</p>
      </div>
      <div>
        <p>ISBN no 978-65-87187-23-5</p>
      </div>
      <div>
        <p>© OIM 2023</p>
        <p>Esta publicação não deve ser usada, publicada ou redistribuída para fins principalmente destinados ou direcionados para vantagem comercial ou compensação monetária, com exceção de fins educacionais, por exemplo, para inclusão em livros didáticos.</p>
      </div>
    </div>
  )
}

export default FolhaRosto;