function Expediente() {
    return (
      <div className="expediente">
        <p className="title-page">Expediente</p>
        <p className="title-1">Governo Federal</p>
        <p className="title-1.1">Ministério dos Povos Indígenas</p>
        <p className="nome">Sônia Guajajara</p>
        <p className="cargo">Ministra</p>
        <p className="nome">Joziléia Kaingang</p>
        <p className="cargo">Secretária de Articulação e Promoção de Direitos Indígenas (SEART)</p>
        <p className="nome">Rosenilda Rodrigues</p>
        <p className="cargo">Chefe de Gabinete da Secretaria de Articulação e Promoção de Direitos Indígenas (SEART)</p>
        <p className="nome">Bruno Kanela de Moura Santos</p>
        <p className="cargo">Coordenador de Políticas Públicas para Indígenas em Situação de Contexto Urbano (COPSU)</p>
        <p className="title-1.1">Fundação Nacional dos Povos Indígenas</p>
        <p className="nome">Joenia Wapichana</p>
        <p className="cargo">Presidenta</p>
        <p className="nome">Lucia Alberta Andrade de Oliveira</p>
        <p className="cargo">Diretoria de Promoção ao Desenvolvimento Sustentável (DPDS)</p>
        <p className="nome">Núbia Batista da Silva</p>
        <p className="cargo">Coordenadora Geral de Promoção da Cidadania (CGPC)</p>
        <p className="nome">André Raimundo Ferreira Ramos</p>
        <p className="cargo">Coordenador de Processos Educativos (COPE)</p>
        <p className="nome">Luiz Carlos Lages</p>
        <p className="cargo">Especialista em Indigenismo (COPE)</p>
        <p className="title-1.1">Organização Internacional para as Migrações</p>
        <p className="nome">Stéphane Rostiaux</p>
        <p className="cargo">Chefe de Missão</p>
        <p className="nome">Luciana Elena Vázquez</p>
        <p className="cargo">Assistente de Projeto</p>
        <p className="nome">Manuela de Castro</p>
        <p className="cargo">Estagiária</p>
      </div>
    )
  }
  
  export default Expediente;