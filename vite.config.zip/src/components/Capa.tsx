function Capa() {
    return (
      <div className="capa">
        <h1>
          <strong>População indígena em mobilidade: </strong>
          do fluxo venezuelano e outros no Brasil
        </h1>
        <img src="logo_oim.svg"/>
      </div>
    )
  }
  
  export default Capa;