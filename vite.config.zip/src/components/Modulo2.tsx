function Modulo2() {
    return (
      <div>
        Modulo2
      </div>
    )
  }
  
  export default Modulo2;