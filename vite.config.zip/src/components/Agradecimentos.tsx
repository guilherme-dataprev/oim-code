function Agradecimentos() {
    return (
      <div className="agradecimentos">
        <p className="title-page">Agradecimentos</p>
        <p>Texto de agradecimento.</p>
      </div>
    )
  }
  
  export default Agradecimentos;
  