function Modulo4() {
    return (
      <div>
        Modulo4
      </div>
    )
  }
  
  export default Modulo4;