function ListaFiguras() {
    return (
      <div className="lista-figuras">
        <p className="title-page">Lista de figuras</p>
        <p className="lista">Figura 1 - Texto da figura<div className="separador"></div><span className="pagina">00</span></p>
      </div>
    )
  }
  
  export default ListaFiguras; 