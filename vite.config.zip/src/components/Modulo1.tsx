function Modulo1() {
    return (
      <div>
        Modulo1
      </div>
    )
  }
  
  export default Modulo1;