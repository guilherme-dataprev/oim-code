// Hiperlink
// Legislação
// Não deixe de conferir!
// Destaque
// Vídeo
// Para refletir
// Abordaremos este tema mais para frente!
function IconesOrganizadores() {
    return (
      <div className="icones-organizadores">
        <p className="title-page">Ícones organizadores</p>
        <span className="hiperlink"></span>
        <span className="legislacao"></span>
        <span className="conferir"></span>
        <span className="destaque"></span>
        <span className="video"></span>
        <span className="refletir"></span>
        <span className="frente"></span>
      </div>
    )
  }
  
  export default IconesOrganizadores;