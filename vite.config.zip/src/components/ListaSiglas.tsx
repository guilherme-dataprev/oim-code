function ListaSiglas() {
    return (
      <div className="lista-siglas">
        <p className="title-page">Lista de siglas</p>
        <p className='definicao'>Agência da ONU para as Migrações <span className='sigla'>OIM/ONU</span></p>
        <p className='definicao'>Acampamento Terra Livre <span className='sigla'>ATL</span></p>
        <p className='definicao'>Associação Nacional de Ação Indigenista <span className='sigla'>ANAÍ</span></p>
        <p className='definicao'>Articulação dos Povos Indígenas do Brasil <span className='sigla'>APIB</span></p>
        <p className='definicao'>Articulação dos Povos Indígenas da Região Sul <span className='sigla'>ARPIN Sul</span></p>
        <p className='definicao'>Articulação dos Povos Indígenas do Nordeste, Minas Gerais e Espírito Santo <span className='sigla'>APOINME</span></p> 
        <p className='definicao'>Articulação dos Povos Indígenas do Sudeste <span className='sigla'>ARPINSUDESTE</span></p>
        <p className='definicao'>Articulação Nacional das Mulheres Indígenas Guerreiras da Ancestralidade <span className='sigla'>ANMIGA</span></p>
        <p className='definicao'>Centro de Direitos Humanos e Cidadania do Imigrante <span className='sigla'>CDHIC</span></p> 
        <p className='definicao'>Conselho Indígena Missionário <span className='sigla'>CIMI</span></p>
        <p className='definicao'>Centro de Trabalho Indigenista <span className='sigla'>CTI</span></p>
        <p className='definicao'>Centro Latinoamericano e Caribenho de Demografia <span className='sigla'>CELADE</span></p>
        <p className='definicao'>Comissão Econômica para a América Latina e o Caribe <span className='sigla'>CEPAL/ONU</span></p>
        <p className='definicao'>Comissão Nacional da Verdade <span className='sigla'>CNV</span></p>
        <p className='definicao'>Conferência Nacional de Migrações, Refúgio e Apatridia <span className='sigla'>COMIGRAR</span></p>
        <p className='definicao'>Conselho Nacional de Imigração <span className='sigla'>CNig</span></p>
        <p className='definicao'>Conselho Nacional de Política Indigenista <span className='sigla'>CNPI</span></p>
        <p className='definicao'>Conselho Nacional de Proteção aos Índios <span className='sigla'>CNPI</span></p>
        <p className='definicao'>Comissão Guarani Yvyrupa <span className='sigla'>CGY</span></p>
        <p className='definicao'>Comissão Pró-Yanomami <span className='sigla'>CCPY</span></p>
        <p className='definicao'>Coordenação das Organizações Indígenas da Amazônia Brasileira <span className='sigla'>COIAB</span></p>
        <p className='definicao'>Delegacia de Ordem Política e Social <span className='sigla'>DOPS</span></p>
        <p className='definicao'>Fórum Social Mundial das Migrações <span className='sigla'>FSMM</span></p>
        <p className='definicao'>Fundação Nacional dos Povos Indígenas <span className='sigla'>FUNAI</span></p>
        <p className='definicao'>Fundo das Nações Unidas para as Crianças <span className='sigla'>UNICEF</span></p>
        <p className='definicao'>Grande Assembleia do Povo Guarani <span className='sigla'>ATY GUASU</span></p>
        <p className='definicao'>Grupo Banco Mundial <span className='sigla'>GBM</span></p> 
        <p className='definicao'>Instituto Brasileiro de Geografia e Estatística <span className='sigla'>IBGE</span></p>
        <p className='definicao'>Instituto do Patrimônio Histórico Artístico Nacional <span className='sigla'>IPHAN</span></p>
        <p className='definicao'>Instituto Socioambiental <span className='sigla'>ISA</span></p>
        <p className='definicao'>Laboratório de Pesquisas em Etnicidade, Cultura e Desenvolvimento <span className='sigla'>LACED</span></p>
        <p className='definicao'>Mecanismo de Expertos sobre os Direitos dos Povos Indígenas <span className='sigla'>MEDPI/CDH/ONU</span></p>
        <p className='definicao'>Ministério da Justiça e Segurança Pública <span className='sigla'>MJSP</span></p>
        <p className='definicao'>Ministério de Relações Exteriores <span className='sigla'>MRE</span></p>
        <p className='definicao'>Ministério dos Povos Indígenas <span className='sigla'>MPI</span></p>
        <p className='definicao'>Ministério do Trabalho e Emprego <span className='sigla'>MTE</span></p>
        <p className='definicao'>Núcleo de Estudos de População Elza Berquó <span className='sigla'>NEPO</span></p>
        <p className='definicao'>Observatório das Migrações Internacionais <span className='sigla'>OBMigra</span></p>
        <p className='definicao'>Organização Internacional do Trabalho <span className='sigla'>OIT</span></p>
        <p className='definicao'>Organização das Nações Unidas <span className='sigla'>ONU</span></p>
        <p className='definicao'>Organização das Nações Unidas para a Educação, a Ciência e a Cultura <span className='sigla'>UNESCO</span></p>
        <p className='definicao'>Polícia Federal <span className='sigla'>PF</span></p>
        <p className='definicao'>Política Nacional de Desenvolvimento Sustentável dos Povos e Comunidades Tradicionais <span className='sigla'>PNPCT</span></p> 
        <p className='definicao'>Registro Nacional Migratório <span className='sigla'>RNM</span></p>
        <p className='definicao'>Serviço de Proteção aos Índios <span className='sigla'>SPI</span></p>
        <p className='definicao'>Serviço de Proteção aos Índios e Localização de Trabalhadores Nacionais <span className='sigla'>SPILTN</span></p>
        <p className='definicao'>Sistema de Registro Nacional Migratório <span className='sigla'>SISMIGRA</span></p>
        <p className='definicao'>Terras Indígenas <span className='sigla'>TI</span></p>
        <p className='definicao'>Universidade de Brasília <span className='sigla'>UnB</span></p>
        <p className='definicao'>Universidade Estadual de Campinas <span className='sigla'>UNICAMP</span></p>
        <p className='definicao'>Universidade de São Paulo <span className='sigla'>USP</span></p>
      </div>
    )
  }
  
  export default ListaSiglas; 