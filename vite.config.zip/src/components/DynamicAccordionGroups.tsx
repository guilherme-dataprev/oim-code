import React from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

// Estrutura de dados para múltiplos grupos de acordeões
const accordionGroupsData = [
  {
    groupId: "group-1",
    groupTitle: "First Accordion Group",
    items: [
      {
        id: "item-1",
        trigger: "Is it accessible?",
        content: "Yes. It adheres to the WAI-ARIA design pattern.",
      },
      {
        id: "item-2",
        trigger: "Is it styled?",
        content: "Yes. It comes with default styles that match the design.",
      },
    ],
  },
  {
    groupId: "group-2",
    groupTitle: "Second Accordion Group",
    items: [
      {
        id: "item-3",
        trigger: "Can I customize it?",
        content: "Yes. You can customize it with your own styles.",
      },
      {
        id: "item-4",
        trigger: "Is it lightweight?",
        content: "Yes. It is built with performance in mind.",
      },
    ],
  },
  {
    groupId: "group-3",
    groupTitle: "Third Accordion Group",
    items: [
      {
        id: "item-5",
        trigger: "Is it responsive?",
        content: "Yes. It works on all devices.",
      },
      {
        id: "item-6",
        trigger: "Is it easy to use?",
        content: "Yes. It's designed with ease of use in mind.",
      },
    ],
  },
  // Adicione mais grupos de acordeões conforme necessário
];

function DynamicAccordionGroups({ groupId }: { groupId: string }) {
  // Encontre o grupo que corresponde ao groupId fornecido
  const group = accordionGroupsData.find(group => group.groupId === groupId);

  if (!group) {
    return <div>Accordion group not found</div>;
  }

  return (
    <div className="mb-8">
      <h2 className="text-xl font-bold mb-4">{group.groupTitle}</h2>
      <Accordion type="single" collapsible>
        {group.items.map(item => (
          <AccordionItem key={item.id} value={item.id}>
            <AccordionTrigger>{item.trigger}</AccordionTrigger>
            <AccordionContent>{item.content}</AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  );
}

export default DynamicAccordionGroups;
