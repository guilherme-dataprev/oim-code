import * as React from "react"
import * as AccordionPrimitive from "@radix-ui/react-accordion"
import { ChevronDownIcon } from "@radix-ui/react-icons"

import { cn } from "@/lib/utils"

const Accordion = AccordionPrimitive.Root

const AccordionItem = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Item>
>(({ className, ...props }, ref) => (
  <AccordionPrimitive.Item
    ref={ref}
    className={cn("oim-border-b", className)}
    {...props}
  />
))
AccordionItem.displayName = "AccordionItem"

const AccordionTrigger = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Trigger>
>(({ className, children, ...props }, ref) => (
  <AccordionPrimitive.Header className="oim-flex">
    <AccordionPrimitive.Trigger
      ref={ref}
      className={cn(
        "oim-flex oim-flex-1 oim-items-center oim-justify-between oim-py-4 oim-text-sm oim-font-medium oim-transition-all hover:oim-underline [&[data-state=open]>svg]:oim-rotate-180",
        className
      )}
      {...props}
    >
      {children}
      <ChevronDownIcon className="oim-h-4 oim-w-4 oim-shrink-0 oim-text-muted-foreground oim-transition-transform oim-duration-200" />
    </AccordionPrimitive.Trigger>
  </AccordionPrimitive.Header>
))
AccordionTrigger.displayName = AccordionPrimitive.Trigger.displayName

const AccordionContent = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Content>
>(({ className, children, ...props }, ref) => (
  <AccordionPrimitive.Content
    ref={ref}
    className="oim-overflow-hidden oim-text-sm data-[state=closed]:oim-animate-accordion-up data-[state=open]:oim-animate-accordion-down"
    {...props}
  >
    <div className={cn("oim-pb-4 oim-pt-0", className)}>{children}</div>
  </AccordionPrimitive.Content>
))
AccordionContent.displayName = AccordionPrimitive.Content.displayName

export { Accordion, AccordionItem, AccordionTrigger, AccordionContent }
