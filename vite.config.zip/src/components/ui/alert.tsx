import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const alertVariants = cva(
  "oim-relative oim-w-full oim-rounded-lg oim-border oim-px-4 oim-py-3 oim-text-sm [&>svg+div]:oim-translate-y-[-3px] [&>svg]:oim-absolute [&>svg]:oim-left-4 [&>svg]:oim-top-4 [&>svg]:oim-text-foreground [&>svg~*]:oim-pl-7",
  {
    variants: {
      variant: {
        default: "oim-bg-background oim-text-foreground",
        destructive:
          "oim-border-destructive/50 oim-text-destructive dark:oim-border-destructive [&>svg]:oim-text-destructive",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
)

const Alert = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & VariantProps<typeof alertVariants>
>(({ className, variant, ...props }, ref) => (
  <div
    ref={ref}
    role="alert"
    className={cn(alertVariants({ variant }), className)}
    {...props}
  />
))
Alert.displayName = "Alert"

const AlertTitle = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLHeadingElement>
>(({ className, ...props }, ref) => (
  <h5
    ref={ref}
    className={cn("oim-mb-1 oim-font-medium oim-leading-none oim-tracking-tight", className)}
    {...props}
  />
))
AlertTitle.displayName = "AlertTitle"

const AlertDescription = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    className={cn("oim-text-sm [&_p]:oim-leading-relaxed", className)}
    {...props}
  />
))
AlertDescription.displayName = "AlertDescription"

export { Alert, AlertTitle, AlertDescription }
