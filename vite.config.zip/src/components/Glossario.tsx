function Glossario() {
    return (
      <div>
        Glossario
      </div>
    )
  }
  
  export default Glossario;