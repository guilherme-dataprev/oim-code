function Modulo3() {
    return (
      <div>
        Modulo3
      </div>
    )
  }
  
  export default Modulo3;