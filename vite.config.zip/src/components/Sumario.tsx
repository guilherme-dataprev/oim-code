function Sumario() {
    return (
      <div className="sumario">
        <p className="title-page">Sumário</p>
        <p className="lista">Texto do sumário<div className="separador"></div><span className="pagina">00</span></p>
      </div>
    )
  }
  
  export default Sumario;