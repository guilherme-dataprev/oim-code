Hiperlink//Rosa - Button
Legislação//Cinza - 
Não deixe de conferir!//Amarelo - Alert
Destaque//Verde claro
Vídeo//Vermelho
Para refletir//Azul claro
Abordaremos este tema mais para frente!//Verde escuro